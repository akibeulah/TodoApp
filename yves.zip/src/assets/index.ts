import logo from "./imgs/Logomark.png"
import bell_icon from "./imgs/bell-01.png"
import cog_icon from "./imgs/cog.png"
import  user_icon from "./imgs/Dropdown.png"

export const logoSmall = {src: logo, alt: "ToDo"}
export const bellIcon = {src: bell_icon, alt: "Notifications"}
export const cogIcon = {src: cog_icon, alt: "Settings"}
export const userIcon = {src: user_icon, alt: "Users"}